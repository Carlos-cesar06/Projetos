// JavaScript para qntestoque.html

document.addEventListener("DOMContentLoaded", function() {
    // Função para buscar os dados dos produtos no Local Storage
    function getStockData() {
      const stockData = JSON.parse(localStorage.getItem('stockData')) || [];
      return stockData;
    }
  
    // Função para exibir os dados dos produtos na tabela
    function displayStockData() {
      const stockTable = document.getElementById('stockTable');
      const stockData = getStockData();
  
      // Limpar conteúdo da tabela
      stockTable.innerHTML = '';
  
      // Adicionar cabeçalho da tabela
      const headerRow = stockTable.insertRow(0);
      headerRow.innerHTML = '<th>Código do Produto</th><th>Nome do Produto</th><th>Quantidade em Estoque</th><th>Preço de Compra</th><th>Preço de Venda</th>';
  
      // Adicionar linhas para cada produto
      stockData.forEach(product => {
        const row = stockTable.insertRow(-1);
        row.innerHTML = `<td>${product.code}</td><td>${product.name}</td><td>${product.quantity}</td><td>${product.unitPrice}</td><td>${product.sellingPrice}</td>`;
      });
    }
  
    // Exibir os dados dos produtos na tabela ao carregar a página
    displayStockData();
  });

  // JavaScript para qntestoque.js

document.addEventListener("DOMContentLoaded", function() {
    const deleteItemsBtn = document.getElementById('deleteItemsBtn');
    const stockTableBody = document.querySelector('#stockTable tbody');
  
    // Função para limpar a tabela de estoque
    function clearStockTable() {
      stockTableBody.innerHTML = '';
    }
  
    // Evento de clique no botão "Excluir Itens"
    deleteItemsBtn.addEventListener('click', function() {
      // Confirmar se o usuário realmente deseja excluir os itens
      if (confirm('Tem certeza de que deseja excluir todos os itens do estoque?')) {
        // Limpar a tabela de estoque
        clearStockTable();
  
        // Limpar os dados de estoque no Local Storage
        localStorage.removeItem('stockData');
      }
    });
  });

  // JavaScript para qntestoque.js

document.addEventListener("DOMContentLoaded", function() {
    const deleteItemBtn = document.getElementById('deleteItemBtn');
    const deleteItemsBtn = document.getElementById('deleteItemsBtn');
    const stockTableBody = document.querySelector('#stockTable tbody');
  
    // Função para limpar a tabela de estoque
    function clearStockTable() {
      stockTableBody.innerHTML = '';
    }
  
    // Evento de clique no botão "Excluir Item"
    deleteItemBtn.addEventListener('click', function() {
      // Solicitar ao usuário o código do produto a ser excluído
      const productCodeToDelete = prompt('Informe o código do produto a ser excluído:');
      if (productCodeToDelete === null) return; // Se o usuário cancelar, sair da função
  
      // Obter os dados dos produtos do Local Storage
      let stockData = JSON.parse(localStorage.getItem('stockData')) || [];
  
      // Remover o produto com o código informado
      stockData = stockData.filter(product => product.code !== productCodeToDelete);
  
      // Atualizar os dados dos produtos no Local Storage
      localStorage.setItem('stockData', JSON.stringify(stockData));
  
      // Atualizar a tabela de estoque
      clearStockTable();
      displayStockData(stockData);
    });
  
    // Restante do código...
  
  });