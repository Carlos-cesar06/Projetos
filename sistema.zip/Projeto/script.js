// JavaScript para addproduct.html

document.addEventListener("DOMContentLoaded", function() {
    const productForm = document.getElementById('productForm');
  
    // Função para lidar com o envio do formulário
    productForm.addEventListener('submit', function(event) {
      event.preventDefault();
  
      // Obter os valores do formulário
      const productName = document.getElementById('productName').value;
      const productCode = document.getElementById('productCode').value;
      const unitPrice = parseFloat(document.getElementById('unitPrice').value);
      const quantity = parseInt(document.getElementById('quantity').value);
      const sellingPrice = parseFloat(document.getElementById('sellingPrice').value);
  
      // Criar objeto com os dados do produto
      const productData = {
        name: productName,
        code: productCode,
        unitPrice: unitPrice,
        quantity: quantity,
        sellingPrice: sellingPrice
      };
  
      // Adicionar dados do produto ao Local Storage
      let stockData = JSON.parse(localStorage.getItem('stockData')) || [];
      stockData.push(productData);
      localStorage.setItem('stockData', JSON.stringify(stockData));
  
      // Redirecionar para a página de quantidade em estoque
      window.location.href = 'qntestoque.html';
    });
  });