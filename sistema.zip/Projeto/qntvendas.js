// JavaScript para vendas.html

document.addEventListener("DOMContentLoaded", function() {
    const salesForm = document.getElementById('salesForm');
  
    // Função para lidar com o envio do formulário de registro de vendas
    salesForm.addEventListener('submit', function(event) {
      event.preventDefault();
  
      // Obter os valores do formulário
      const productCode = document.getElementById('productCode').value;
      const quantitySold = parseInt(document.getElementById('quantitySold').value);
  
      // Obter os dados dos produtos do Local Storage
      let stockData = JSON.parse(localStorage.getItem('stockData')) || [];
  
      // Atualizar a quantidade em estoque do produto correspondente
      stockData.forEach(product => {
        if (product.code === productCode) {
          product.quantity -= quantitySold;
  
          // Exibir um alerta quando a quantidade em estoque ficar abaixo de 10 unidades
          if (product.quantity < 10) {
            alert(`Atenção: O produto ${product.name} está com quantidade em estoque abaixo de 10 unidades.`);
          }
        }
      });
  
      // Atualizar os dados dos produtos no Local Storage
      localStorage.setItem('stockData', JSON.stringify(stockData));
  
      // Limpar o formulário
      salesForm.reset();
    });
  });