document.querySelector('.menuImg').addEventListener('click', function() {
    document.querySelector('.menu').classList.toggle('active');
  });
  
  const dailyTableBody = document.querySelector('#dailyTable tbody');
  const annualTableBody = document.querySelector('#annualTable tbody');
  
  let currentDay = null;
  let monthlyData = [];
  let annualData = [];
  
  document.getElementById('startDay').addEventListener('click', () => {
    if (!currentDay) {
      currentDay = new Date().toLocaleDateString();
      const newRow = dailyTableBody.insertRow();
      newRow.insertCell(0).innerText = currentDay;
      newRow.insertCell(1).innerText = 0;
      newRow.insertCell(2).innerText = 0;
      newRow.insertCell(3).innerText = 0;
    } else {
      alert('O dia já foi iniciado.');
    }
  });
  
  document.getElementById('endDay').addEventListener('click', () => {
    if (currentDay) {
      const dailyRows = dailyTableBody.rows;
      const lastRow = dailyRows[dailyRows.length - 1];
  
      const spent = Math.floor(Math.random() * 1000);
      const earned = Math.floor(Math.random() * 1500);
      const profit = earned - spent;
  
      lastRow.cells[1].innerText = spent;
      lastRow.cells[2].innerText = earned;
      lastRow.cells[3].innerText = profit;
  
      monthlyData.push(profit);
  
      if (dailyRows.length >= 30) {
        const monthlyProfit = monthlyData.reduce((acc, val) => acc + val, 0);
        const monthRow = annualTableBody.insertRow();
        monthRow.insertCell(0).innerText = `Mês ${annualTableBody.rows.length + 1}`;
        monthRow.insertCell(1).innerText = monthlyProfit;
  
        dailyTableBody.innerHTML = '';
        monthlyData = [];
      }
  
      currentDay = null;
    } else {
      alert('O dia ainda não foi iniciado.');
    }
  });