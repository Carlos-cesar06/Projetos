// JavaScript para reabastecer.js

document.addEventListener("DOMContentLoaded", function() {
    const restockForm = document.getElementById('restockForm');
    const productCodeSelect = document.getElementById('productCode');
  
    // Função para preencher o menu suspenso com os códigos dos produtos disponíveis
    function populateProductCodes() {
      // Obter os dados dos produtos do Local Storage
      const stockData = JSON.parse(localStorage.getItem('stockData')) || [];
  
      // Limpar opções existentes do menu suspenso
      productCodeSelect.innerHTML = '';
  
      // Adicionar opções ao menu suspenso
      stockData.forEach(product => {
        const option = document.createElement('option');
        option.value = product.code;
        option.textContent = product.code;
        productCodeSelect.appendChild(option);
      });
    }
  
    // Exibir os códigos dos produtos ao carregar a página
    populateProductCodes();
  
    // Evento de envio do formulário de reabastecimento
    restockForm.addEventListener('submit', function(event) {
      event.preventDefault();
  
      // Obter os valores do formulário
      const productCode = productCodeSelect.value;
      const quantityToAdd = parseInt(document.getElementById('quantityToAdd').value);
  
      // Obter os dados dos produtos do Local Storage
      let stockData = JSON.parse(localStorage.getItem('stockData')) || [];
  
      // Atualizar a quantidade em estoque do produto correspondente
      stockData.forEach(product => {
        if (product.code === productCode) {
          product.quantity += quantityToAdd;
        }
      });
  
      // Atualizar os dados dos produtos no Local Storage
      localStorage.setItem('stockData', JSON.stringify(stockData));
  
      // Limpar o formulário
      restockForm.reset();
  
      // Exibir uma mensagem de sucesso
      alert('Produto reabastecido com sucesso!');
    });
  });