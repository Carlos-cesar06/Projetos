import React from 'react';
import Home from './pages/Home';
import Perfil from './pages/Perfil';
import Login from './pages/Login';
import Cadastro from './pages/Cadastro';
import Configuracoes from './pages/Configuracoes';
import BarPesq from './pages/BarPesq';
import Post from './pages/Post';
import Publi from './pages/Publi';
import RecSenha from './pages/RecSenha';
import Sac from './pages/Sac';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import './styles/BarPesq.css';
import './styles/Sac.css';
import './styles/Recsen.css';
import './styles/Publi.css';
import './styles/Post.css';
import './styles/Perfil.css';
import './styles/Log.css';
import './styles/Inicial.css';
import './styles/Config.css';
import './styles/Cad.css';


function App() {

  return (
    <>
   
   <Router>
    <Routes>
      <Route path="/" element={<Login/>} />
      <Route path="/cadastro" element={<Cadastro />} />
      <Route path="/home" element={<Home />} />
      <Route path="/perfil" element={<Perfil />} />
      <Route path="/configuracoes" element={<Configuracoes />} />
      <Route path="/pesquisa" element={<BarPesq />} />
      <Route path="/postagem" element={<Post />} />
      <Route path="/publicacao" element={<Publi />} />
      <Route path="/recuperacao" element={<RecSenha />} />
      <Route path="/sac" element={<Sac />} />
    </Routes>
   </Router>

    </>
  )
}

export default App
