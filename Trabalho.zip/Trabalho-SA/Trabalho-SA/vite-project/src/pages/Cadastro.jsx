import { useNavigate } from 'react-router-dom';

export default function Cadastro(){

    const Navigate = useNavigate()

    return(
        <>
        <div className="telaLog">
        <div className="log">
        <h1>Talent ShowCase</h1>
        <button>Entrar com Google</button>
        <br /><br />
        <form className="senhas">
            <label>Email:</label>
        <input type="text" />
            <label>Nome de usuário:</label>
        <input type="text" />
            <label>Senha:</label>
        <input type="password" />
            <label>Confirme a senha:</label>
        <input type="password" />
        </form>
        <br /><br />
        <button onClick={() => Navigate("/home")}>Cadastrar</button>
        <br /><br />
        <a onClick={() => Navigate("/")}>Já tem conta? Faça Login!</a>
            </div>
        </div>
   </>
)
}