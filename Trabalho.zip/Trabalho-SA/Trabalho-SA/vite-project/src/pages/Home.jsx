import { useNavigate } from 'react-router-dom';

export default function Home() {

const Navto = useNavigate();

    return (
        <>
        <div >
     <header>
     <h1>Publicações</h1>

<div class="cabecalho">
<button class="botonP"><a href="/Pesquisa.jsx">Pesquisar</a></button>
</div>

<div>
    <nav class="perfil">
        <ul>
            <li onClick={() => Navto("/perfil")}>Perfil</li>
            <li onClick={() => Navto("/configuracoes")}>Configurações</li>
        </ul>
    </nav>
</div>

     </header>

<div class="fundo">
<h2>Não há videos postados</h2>
</div>
</div>

        </>
    )
}