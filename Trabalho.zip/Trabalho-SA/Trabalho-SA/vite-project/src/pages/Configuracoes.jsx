import { useNavigate } from 'react-router-dom';

export default function Configuracoes(){

    const Navigate = useNavigate()

    return(
        <>
        <div className="body_">
        <header>
        <h1 onClick={() => Navigate("/home")}>Talent ShowCase</h1>
        </header>
        <div className="configs">
            <img src="user.jpg" class="imguser"/>
            <form className="info">
            <label>Nome:</label>
        <input type="text" />
        <br />
            <label>Nome usuário:</label>
        <input type="text" />
        <br />
        <label>Gênero de perfil:</label>
        <input type="text" />
        <br />
        </form>
        </div>
        <div>
            <form class="info_">
            <label>Biografia:</label>
        <input type="text" />
            </form>
        </div>
        </div>    
        </>
    )
    }