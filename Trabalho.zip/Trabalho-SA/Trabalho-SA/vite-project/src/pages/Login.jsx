import { useNavigate } from 'react-router-dom';

export default function Login(){

    const Navigate = useNavigate()

    return(
        <>
        <div className="logTela">
            <div className="gol2">
        <div className="gol">
        <img src="./public/logo.jpg" />
        <br /><br />
        <button><a onClick={() => Navigate("/cadastro")}>Não tem cadastro? Cadastre-se!</a></button>
        <br /><br />
            </div>
            <form className="senha">
            <label>Email ou Nome de usuário:</label>
        <input type="text" className='barra'/>
            <label>Senha:</label>
        <input type="password" className='barra'/>
        <a href="">Esqueceu a senha?</a>
        </form>
            <button onClick={() => Navigate("/home")}>Entrar</button>
            </div>
        </div>
   </>
)
}