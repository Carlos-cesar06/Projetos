import { useNavigate } from 'react-router-dom';

export default function Perfil(){

    const Navigate = useNavigate()

    return(
        <>
       
       <div class="conta">
        <header>
        <h1 onClick={() => Navigate("/home")}>Talent ShowCase</h1>

<div class="cabecalho">
<button class="botonP"><a href="/BarPesq.jsx">Pesquisar</a></button>
</div>
        </header>
        </div> 
        <div class="interno">
            <img src="user.jpg" class="imguser"/>
            <div class="dentro">
                <h3>Olá, #######!</h3><br />
            <button onClick={() => Navigate("/configuracoes")}>Configurações</button>
            <br />
            <button>Saldo</button>
            </div>
        </div>
        <div class="fundo_">
<h2>Não há videos postados</h2>
</div>
        </>
    )
}